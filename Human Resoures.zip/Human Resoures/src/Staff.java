
public abstract class Staff {  //Class co tinh truu tuong.
	private String staffCode; //Ma nhan vien
	private String staffName; // Ten nhan vien
	private int age; //tuoi nhan vien
	private int salaryRate; //He so luong 
	private String startDay; //Ngay bat dau
	private String departmentld; // Bo phan lam viec 
	private int dayOff; // So ngay nghi phep
	private long salary; //Luong nhan vien
	
	protected Staff (String staffCode, String staffName, int age, int salaryRate, String startDay, String departmentld, int dayOff) {
		this.staffCode = staffCode;
		this.staffName = staffName;
		this.age = age;
		this.salaryRate = salaryRate;
		this.startDay = startDay;
		this.departmentld = departmentld;
		this.dayOff = dayOff;
	}
	
	public String getStaffCode() { // Phuong thuc getter: tra ve thuoc tinh doi tuong
		return staffCode;
	}
	public String getStaffName() {
		return staffName;
	}
	public int getAge() {
		return age;
	}
	public int getSalaryRate() {
		return salaryRate;
	}
	public String getStartDay () {
		return startDay;
	}
	public String getDepartmentld() {
		return departmentld;
	}
	public int getDayOff ()  {
		return dayOff;
	}
	public long getSalary () {
		return salary;
	}
	
	public void setStaffCode(String staffCode) { // Phuong thuc setter: gan gia tri
		this.staffCode = staffCode;
	}
	public void setStaffName (String staffName) {
		this.staffName = staffName;
	}
	public void setAge (int age) {
		this.age = age;
	}
	public void setSalaryRate (int salaryRate) {
		this.salaryRate = salaryRate;
	}
	public void setStartDay (String startDay) {
		this.startDay = startDay;
	}
	public void setDepartmentld (String departmentld) {
		this.departmentld = departmentld;
	}
	public void setDayOff (int dayOff) {
		this.dayOff = dayOff;
	}
	public void setSalary (long Salary) {
		this.salary = Salary;
	}
	
	public abstract String toString();
}














