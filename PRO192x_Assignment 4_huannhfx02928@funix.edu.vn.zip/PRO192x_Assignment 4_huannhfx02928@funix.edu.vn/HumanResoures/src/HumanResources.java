import java.util.Scanner;

public class HumanResources {
	public static void main (String [] args) {
		System.out.println("Welcome to the Human Resource Management app.");
		Scanner input = new Scanner(System.in);
		HumanResourceService list = new HumanResourceService();
		boolean ktExit = true;
		do {
			System.out.println("-----------------\n1. Displays a list of employees currently in the company");
			System.out.println("2. Show departments in the company");
			System.out.println("3. Show employees by department");
			System.out.println("4. Add new employees to the company");
			System.out.println("5. Search employee information by employee name or employee code");
			System.out.println("6. Display the payroll of employees throughout the company");
			System.out.println("7. Display employee payroll in ascending order\n8. Exit");
			boolean ktso = true;
			do {
				System.out.print("Your choice: ");
				ktso = false;
				int yourChoice = input.nextInt();
				switch (yourChoice) {
				  case 1: 
				    list.display();
				    break;
				  case 2: 
				    list.displayDepartment();
				    break;
				  case 3: 
				    list.staffDepartment ();
				    break;
				  case 4: 
				    list.addStaff();
				    break;
				  case 5: 
				    list.search();
				    break;
				  case 6: 
				    list.showDescendingSalary();
				    break;
				  case 7: 
				    list.showAscendingSalary();
				    break;
				  case 8: 
				    ktExit = false;
				    break;
				  default:
				    ktso = true;
				    System.out.println("Please enter an integer in range 1 - 8!" );
				    break;
				}
			} while (ktso);
		} while(ktExit);
	}
}
