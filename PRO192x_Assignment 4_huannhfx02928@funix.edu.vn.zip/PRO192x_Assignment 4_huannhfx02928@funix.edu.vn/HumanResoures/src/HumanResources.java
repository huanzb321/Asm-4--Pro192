import java.util.Scanner;

public class HumanResources {
	public static void main (String [] args) {
		System.out.println("Welcome to the Human Resource Management app.");
		Scanner input = new Scanner(System.in);
		HumanResourceService list = new HumanResourceService();
		boolean ktExit = true;
		do {
			System.out.println("-----------------\n1. Displays a list of employees currently in the company");
			System.out.println("2. Show departments in the company");
			System.out.println("3. Show employees by department");
			System.out.println("4. Add new employees to the company");
			System.out.println("5. Search employee information by employee name or employee code");
			System.out.println("6. Display the payroll of employees throughout the company");
			System.out.println("7. Display employee payroll in ascending order\n8. Exit");
			boolean ktso = true;
			do {
				System.out.print("Your choice: ");
				if (input.hasNextInt()) { // Kiem tra nguoi dung nhap so hay la chu
					ktso = false;
					int yourChoice = input.nextInt();
					if (yourChoice == 1) { //Nguoi dung chon 1 : Hien thi danh sach nhan vien hien co trong cong ty
						ktso = false;
						list.display();
					} else if (yourChoice == 2) { //Nguoi dung chon 2: Hien thi cac bo phan trong cong ty
						ktso = false;
						list.displayDepartment();
					} else if (yourChoice == 3) { //Nguoi dung nhap 3: Hien thi cac nhan vien theo tung bo phan
						ktso = false;
						list.staffDepartment ();
					} else if (yourChoice == 4) { //Nguoi dung nhap 4: Them nhan vien moi vao cong ty
						ktso = false;
						list.addStaff();
					} else if (yourChoice == 5) { //Nguoi dung nhap 5: Tim kiem thong tin nhan vien theo ten hoac ma nhan vien
						ktso = false;
						list.search();
					} else if (yourChoice == 6) { //Nguoi dung nhap 6: Hien thi bang luong cua nhan vien toan cong ty
						ktso = false;
						list.showDescendingSalary();
					} else if (yourChoice == 7) { //Nguoi dung nhap 7: Hien bang luong cua nhan vien theo thu tu tang dan 
						ktso = false;
						list.showAscendingSalary();
					} else if (yourChoice == 8) { //Nguoi dung nhap 8: Dung chuong trinh
						ktso = false;
						ktExit = false;
					} else {
						ktso = true;
						System.out.println("You must enter the options above!" );
					}
				} else {
					ktso = true;
					System.out.println("You must enter the number!");
					input.next();
				}
			} while (ktso);
		} while(ktExit);
	}
}
