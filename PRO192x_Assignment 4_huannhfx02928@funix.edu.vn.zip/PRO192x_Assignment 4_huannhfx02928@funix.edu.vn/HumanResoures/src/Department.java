
public class Department { // Chua thong tin chung ve bo phan
	private String departmentId ; // Ma bo phan
	private String departmentName; // Ten bo phan
	private int numberOfStaff; // So nhan vien hien tai
	public Department (String departmentId, String departmentName, int numberOfStaff) { //
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.numberOfStaff = numberOfStaff;
	}
	
	public String getDepartmentId () { // Phuong thuc getter: tra ve thuoc tinh doi tuong
		return departmentId;
	}
	public String getDepartmentName () {
		return departmentName;
	}
	public int getNumberOfStaff() {
		return numberOfStaff;
	}
	
	public void setDepartmentId (String departmentId) { // Phuong thuc setter: gan gia tri
		this.departmentId = departmentId;
	}
	public void setDepartmentName (String departmentName) {
		this.departmentName = departmentName;
	}
	public void setSnvHienTai (int numberOfStaff) {
		this.numberOfStaff = numberOfStaff;
	}
	public String toString () { // Tra ve chuoi dai dien cho doi tuong
		return String.format("%-20s%-20s%-20d", getDepartmentId(), getDepartmentName(), getNumberOfStaff());
	}
}
