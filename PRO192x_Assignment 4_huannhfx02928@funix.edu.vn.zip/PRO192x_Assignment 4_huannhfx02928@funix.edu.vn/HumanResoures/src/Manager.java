
public class Manager extends Staff implements ICalculator {
	private String position;
	public Manager (String staffCode, String staffName, int age, int salaryRate, String startDay,
			String departmentld, int dayOff,String position) {
		super(staffCode, staffName, age, salaryRate, startDay, departmentld, dayOff);
		this.position = position;
	}
	public String getPosition () { // Phuong thuc getter: tra ve thuoc tinh doi tuong
		return position;
	}
	public void setPosition (String position) { // Phuong thuc setter: gan gia tri
		this.position = position;
	}
	@Override
	public long calculateSalary() { // Tinh luong quan ly 
		if (getPosition().equalsIgnoreCase("Business Leader")) { // Luong Quan ly ban hang
			return getSalaryRate() * 5000000 + 8000000;
		} else if (getPosition().equalsIgnoreCase("Project Leader")) { // Luong quan ly ke hoach va du an
			return getSalaryRate() * 5000000 + 5000000;
		} else if (getPosition().equalsIgnoreCase("Technical Leader")) { // Luong quan ly ky thuat
			return getSalaryRate() * 5000000 + 6000000;
		} else {
			return 0;
		}
	}
	@Override
	public String toString() { // Tra ve chuoi dai dien cho doi tuong
		return String.format("%-20s%-20s%-20d%-20d%-20s%-20s%-20d%-20s%-40s", getStaffCode(), getStaffName(), getAge(), getSalaryRate(), getStartDay(), getDepartmentld(), getDayOff(), "", getPosition ());
	}
}
