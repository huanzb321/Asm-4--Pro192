
public interface ICalculator {
	long calculateSalary();
}

