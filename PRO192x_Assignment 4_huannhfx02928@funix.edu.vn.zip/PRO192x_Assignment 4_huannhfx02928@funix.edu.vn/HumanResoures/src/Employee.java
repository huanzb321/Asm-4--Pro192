
public class Employee extends Staff implements ICalculator {
	private int overtime;
	public Employee(String staffCode, String staffName, int age, int salaryRate, String startDay,
			String departmentld, int dayOff,int overtime) {
		super(staffCode, staffName, age, salaryRate, startDay, departmentld, dayOff);
		this.overtime = overtime;
	}
	public int getOverTime () { // Phuong thuc getter: tra ve thuoc tinh doi tuong
		return overtime;
	}
	public void setOverTime (int overtime) { // Phuong thuc setter: gan gia tri
		this.overtime = overtime;
	}
	@Override
	public long calculateSalary() { // Phuong thuc tinh luong nhan vien
		return getSalaryRate() *3000000 + overtime*200000;
	}
	@Override
	public String toString() {
		return String.format("%-20s%-20s%-20d%-20d%-20s%-20s%-20d%-20d", getStaffCode(), getStaffName(), getAge(), getSalaryRate(), getStartDay(), getDepartmentld(), getDayOff(), getOverTime());
	}
	
}

