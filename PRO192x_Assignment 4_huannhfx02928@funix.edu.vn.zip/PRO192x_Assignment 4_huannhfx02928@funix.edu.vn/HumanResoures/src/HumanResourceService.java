
import java.util.*;
public class HumanResourceService {
	List<Staff> resources = new ArrayList<> ();
	List<Department> departments = new ArrayList<>();
	/*
	 * Nguoi dung chon 1: hien thi cac nha vien trong cong ty
	 */
	public void display () { 
		System.out.println(String.format("%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s", "Staff Code", "Staff Name", "Age", "Salary Rate", "StartDay", "Departmentld", "Day Off", "OverTime", "Position")); 
		for (Staff fullStaff : resources) {
			System.out.println(fullStaff.toString());
		}
	}
	public HumanResourceService() {
		initDefaultEmployee();
	}
	private void initDefaultEmployee () { 
		// Cac employee mac dinh
		resources.add(new Manager("FO3E", "NGUYEN VAN A" , 30, 4, "10/10/2002", "Department 1", 3 ,"Business Leader"));
		resources.add(new Manager("H2PI", "TRAN THI B" , 26, 9, "20/2/2000", "Department 3", 4 ,"Project Leader"));
		resources.add(new Manager("OWU3K", "BUI QUANG C" , 28, 7, "30/5/2005", "Department 2", 6 ,"Technical Leader"));
		resources.add(new Employee("OKL9P", "NGUYEN THI T" , 24, 10, "16/10/2001", "Department 2", 6,6));
	}
	
	/*
	 * Nguoi dung chon 2: Hien thi cac bo phan trong cong ty
	 */
	public void displayDepartment() { 
		int sumStaff1 = 0;
		int sumStaff2 = 0;
		int sumStaff3 = 0;
		for (Staff staff: resources) {  // tinh tong so nhan vien trong moi Bo phan
			if (staff.getDepartmentld().equals("Department 1")) {
				sumStaff1 += 1;
			} else if (staff.getDepartmentld().equals("Department 2")) {
				sumStaff2 += 1;
			} else if (staff.getDepartmentld().equals("Department 3")) {
				sumStaff3 += 1;
			}
		}
		// Mot so bo phan mac dinh
		departments.add(new Department("dept1", "Department 1", sumStaff1));
		departments.add(new Department("dept2", "Department 2", sumStaff2));
		departments.add(new Department("dept3", "Department 3", sumStaff3));
		System.out.println(String.format("%-20s%-20s%-20s", "Part code", "Part name", "Number of employees"));
		for (Department dept : departments) {
			System.out.println(dept.toString());
		}
		departments.clear();
	}
	/*
	 * Nguoi dung chon 3: Hien thi nhan vien theo tung bo phan
	 */
	public void staffDepartment () {
		int sumStaff1 = 0;
		int sumStaff2 = 0;
		int sumStaff3 = 0;
		for (Staff staff: resources) { // tinh tong so nhan vien trong moi Bo phan
			if (staff.getDepartmentld().equals("Department 1")) {
				sumStaff1 += 1;
			} else if (staff.getDepartmentld().equals("Department 2")) {
				sumStaff2 += 1;
			} else if (staff.getDepartmentld().equals("Department 3")) {
				sumStaff3 += 1;
			}
		}
		// Mot so bo phan mac dinh
		departments.add(new Department("dept1", "Department 1", sumStaff1));
		departments.add(new Department("dept2", "Department 2", sumStaff2));
		departments.add(new Department("dept3", "Department 3", sumStaff3));
		for (Department dept : departments) {
			System.out.println(String.format("%-20s%-20s%-20s", "Part code", "Part name", "Number of employees"));
			System.out.println(dept.toString());
			System.out.println(String.format("%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s", "Staff Code", "Staff Name", "Age", "Salary Rate", "StartDay", "Departmentld", "Day Off", "OverTime", "Position"));
			for (Staff staffs: resources) {
				if (dept.getDepartmentName().equalsIgnoreCase(staffs.getDepartmentld())) {
					System.out.println(staffs.toString());
				}
			}
			System.out.println("");
		}
		departments.clear();
	}
	/*
	 * Nguoi dung chon 4 : Them nhan vien
	 */
	Scanner inputString = new Scanner(System.in);
	Scanner inputNumber = new Scanner(System.in);
	public void addStaff () {
		boolean checkIdStaff = false;
		String code = "";
		do {
			System.out.print("Enter staff Code: "); // Nhap ma nhan vien
			code = inputString.nextLine();
			for (Staff staff: resources) {
				if (staff.getStaffCode().equalsIgnoreCase(code)) { // Kiem tra trong danh sach da co ma nhan vien hay chua?
					checkIdStaff= true;
					System.out.println("Employee code already in the list!");
					break;
				}  else {
					checkIdStaff= false;
				}
			}
			if (code.equals("")) {
				checkIdStaff= true;
				System.out.println("You must enter the employee code!");
			} else {
				checkIdStaff= false;
			}
		} while (checkIdStaff);
		
		String name = "";
		boolean checkNameStaff = false;
		do {
			System.out.print("Enter staff Name: "); // Nhap ten nhan vien 
			 name = inputString.nextLine();
			if (name.equals("")) {
				checkNameStaff= true;
				System.out.println("Must not be empty, please enter information!");
			} else {
				checkNameStaff= false;
			}
		} while (checkNameStaff);
		
		boolean ageCheck = true;
		int age = 0;
		do {
			System.out.print("Enter Employee Age: "); // Nhap tuoi nhan vien
			if (inputNumber.hasNextInt()) {
				ageCheck = false;
				age = inputNumber.nextInt();
			} else {
				ageCheck = true;
				System.out.println("Please enter an integer!");
				inputNumber.next();
			}
		} while (ageCheck);
		
		boolean salaryRateCheck = true;
		int salaryRate = 0 ;
		do {
			System.out.print("Enter salary Rate: "); // Nhap he so luong
			if (inputNumber.hasNextInt()) { // kiem tra nguoi dung nhap chu hay so
				salaryRateCheck = false;
				salaryRate = inputNumber.nextInt();
			} else {
				salaryRateCheck = true;
				System.out.println("Please enter a decimal!");
				inputNumber.next();
			}
		} while (salaryRateCheck);
		
		boolean checkStartDay = false;
		String startDay = "";
		do {
			System.out.print("Enter start Day: "); // Nhap ngay bat dau
			startDay = inputString.nextLine();
			if (startDay.equals("")) { //Kiem tr nguoi dung co bo trong thong tin hay khong
				checkStartDay= true;
				System.out.println("Must not be empty, please enter information!");
			} else {
				checkStartDay= false;
			}
		} while (checkStartDay);
		
		boolean isInvalidDept = true;
		String departmentld = "";
		do {
			System.out.println("Which department is the staff member?\n1. Department 1\n2. Department 2\n3. Department 3"); 
			System.out.print("You choose 1 or 2 or 3: ");
			if (inputNumber.hasNextInt()) { // Kiem tra nguoi dung nhap chu hay so
				int numberDept = inputNumber.nextInt();
				if (numberDept == 1) {
					isInvalidDept = false;
					departmentld = "Department 1";
				} else if (numberDept == 2) {
					isInvalidDept = false;
					departmentld = "Department 2";
				} else if (numberDept == 3) {
					isInvalidDept = false;
					departmentld = "Department 3";
				} else {
					isInvalidDept = true;
					System.out.println("You must enter 1 or 2 or 3");
				}
			} else {
				isInvalidDept = true;
				System.out.println("Please enter an integer!");
				inputNumber.next();
			}
		} while (isInvalidDept);
		
		boolean dayOffCheck = true;
		int dayOff = 0 ;
		do {
			System.out.print("Number of days off: "); // Nhap so ngay nghi phep
			if (inputNumber.hasNextInt()) { // kiem tra nguoi dung nhap chu hay so
				dayOffCheck = false;
				dayOff = inputNumber.nextInt();
			} else {
				dayOffCheck = true;
				System.out.println("Please enter an integer!");
				inputNumber.next();
			}
		} while (dayOffCheck);
		
		boolean staffCheck = true; // Hoi nguoi dung them nha vien quan ly hay nhan vien thong thuong 
		String position = "" ;
		int overTime = 0;
		do {
			System.out.println("What staff did you just enter? \n1.Normal \n2.Postition"); // Chon loai nha vien can them vao
			System.out.print("You choose 1 or 2: ");
			if (inputNumber.hasNextInt()) { // kiem tra nguoi dung nhap chu hay so
				int user = inputNumber.nextInt();
				if (user == 1) {  // kiem tra nguoi dung muon them nhan vien nao
					staffCheck = false;
					boolean check = true;
					do {
						System.out.print("Number of overtime hours of staffs? ");
						if (inputNumber.hasNextInt()) { // kiem tra nguoi dung nhap chu hay so
							check =  false;
							overTime = inputNumber.nextInt();
							addEmployee (code, name.toUpperCase(), age, salaryRate, startDay, departmentld, dayOff,overTime); // Goi ham addEmployee truyen gia tri
							System.out.println("A new employee has been added");
						} else {
							check = true;
							System.out.print("Please enter an integer!");
							inputNumber.next();
						}
					} while (check);
				} else if (user == 2) {
					staffCheck = false;
					boolean isInvalidPosition = true;
					do {
						System.out.println("Employees in any position? \n1. Business Leader\n2. Project Leader\n3. Technical Leader"); 
						System.out.print("You must enter 1 or 2 or 3: ");
						if (inputNumber.hasNextInt()) {  // Kiem tra nguoi dung nhap so hay la chu
							int numberPosition = inputNumber.nextInt();
							if (numberPosition == 1 ) { // Kiem tra nguoi dung chon nhan vien chuc vu gi 
								isInvalidPosition = false;
								position = "Business Leader";
							} else if (numberPosition == 2) {
								isInvalidPosition = false;
								position = "Project Leader";
							} else if (numberPosition == 3) {
								isInvalidPosition = false;
								position = "Technical Leader";
							} else {
								isInvalidPosition = true;
								System.out.println("You must enter 1 or 2 or 3");
							}
							addManager (code, name.toUpperCase(), age, salaryRate, startDay, departmentld, dayOff,position); // Goi ham addManager truyen gia tri
							System.out.println("A new employee has been added");
						} else {
							isInvalidPosition = true;
							inputNumber.next();
							System.out.println("Please enter an integer!");
						}
					} while (isInvalidPosition);
				} else {
					staffCheck = true;
					System.out.println("You must enter 1 or 2");
				}
			} else {
				staffCheck = true;
				System.out.println("Please enter an integer!");
				inputNumber.next();
			}
		} while (staffCheck);
	}
	public void addEmployee(String code, String name, int age, int salaryRate, String startDay, String departmentld, int dayOff, int overTime) {
		Staff staff =  new Employee(code, name, age, salaryRate, startDay, departmentld, dayOff, overTime);
		resources.add(staff); // Them cac thong tin cua nguoi dung nhap vao resources
	}
	
	public void addManager(String code, String name, int age, int salaryRate, String startDay, String departmentld, int dayOff, String position) {
		Staff staff = new Manager(code, name, age, salaryRate, startDay, departmentld, dayOff,position); // Khoi tao doi tuong con trong 
		resources.add(staff); // Them cac thong tin cua nguoi dung nhap vao resources
	}
	
	/*
	 * Nguoi dung chon 5: Tim kiem thong tin nhan vien theo ten hoac ma nhan vien
	 */
	public void search () { 
		boolean checkSearch = false;
		String searchKey = "";
		do {
			System.out.println("Enter staff name to search.");
			System.out.print("Staff name: ");
			searchKey = inputString.nextLine();
			if (searchKey.equals("")) { //Kiem tr nguoi dung co bo trong thong tin hay khong
				checkSearch= true;
				System.out.println("Must not be empty, please enter information!");
			} else {
				checkSearch= false;
			}
		} while (checkSearch);
		List<Staff> staffsFound = new ArrayList<>();
		for (Staff staffs: resources) {
			if (staffs.getStaffName().contains(searchKey.toUpperCase())) { //Goi methor getgetStaffName() trong class Book
				 staffsFound.add(staffs); // add cac phan tu vao mang booksFound
			}
		}
		if (staffsFound.isEmpty()) {  //Kiem tra va in ra gia tri tim thay
			System.out.println("No staff found");
		} else {
			System.out.println(String.format("%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s", "Staff Code", "Staff Name", "Age", "Salary Rate", "StartDay", "Departmentld", "Day Off", "OverTime", "Position"));
			for (Staff staff : staffsFound ) {
				System.out.println(staff.toString());
			}
		}
	}
	
	private ICalculator calculator;
	public void setSalaryForAllStaff () { 
		for (Staff staffSalary: resources) {
			calculator = (ICalculator) staffSalary; //Ep kieu cho doi tuong staffSalary
			long salary = calculator.calculateSalary(); // Goi ham tinh luong
			staffSalary.setSalary(salary); // Gan gia tri cho thuoc tinh salary
		}
	}
	/*
	 * Nguoi dung chon 6: Xap sep nhan vien giam dan theo muc luong dat duoc
	 */
	public void showDescendingSalary() {
		setSalaryForAllStaff();
		resources.sort(Comparator.comparingLong(Staff::getSalary)); // Sap xep lai mang nhan vien
		Collections.reverse(resources); // Sap xep theo thu tu giam dan
		System.out.println(String.format("%-270s%-20s%-20s", "Staff Code", "Staff Name", "Salary"));
		for (Staff staffSalary: resources) { 
			System.out.println(String.format("%-20s%-20s%-20d", staffSalary.getStaffCode(), staffSalary.getStaffName(), staffSalary.getSalary()));
		}
	}
	
	/*
	 * Nguoi dung chon 7: Xap sep nhan vien tang dan theo muc luong dat duoc
	 */
	public void showAscendingSalary() {
		setSalaryForAllStaff();
		resources.sort(Comparator.comparingLong(Staff::getSalary)); // Sap xep
		System.out.println(String.format("%-20s%-20s%-20s", "Staff Code", "Staff Name", "Salary"));
		for (Staff staffSalary: resources) {
			System.out.println(String.format("%-20s%-20s%-20d", staffSalary.getStaffCode(), staffSalary.getStaffName(), staffSalary.getSalary()));
		}
	}
}
